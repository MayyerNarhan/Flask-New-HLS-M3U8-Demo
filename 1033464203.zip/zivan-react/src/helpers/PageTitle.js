export const pageTitle = title => {
  return (document.title = title + ' - Creative Agency React App');
};
